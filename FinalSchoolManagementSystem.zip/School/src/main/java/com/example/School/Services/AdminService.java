package com.example.School.Services;


import java.util.List;

import com.example.School.entity.Admin;





public interface AdminService {
	
public Admin saveAdmin(Admin admin);

public List<Admin> adminList();

}
