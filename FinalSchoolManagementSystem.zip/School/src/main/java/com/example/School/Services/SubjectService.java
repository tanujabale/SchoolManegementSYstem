package com.example.School.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.School.Repository.SubjectRepository;
import com.example.School.entity.Subject;

@Service
public class SubjectService {

    @Autowired
    private SubjectRepository subjectRepository;

    public void saveSubject(Subject subject) {
        subjectRepository.save(subject);
    }

    public List<Subject> getAllSubjects() {
        return subjectRepository.findAll();
    }

    public Subject getSubjectById(Long id) {
        return subjectRepository.findById(id).orElse(null);
    }

    public void deleteSubjectById(Long id) {
        subjectRepository.deleteById(id);
    }
}

