package com.example.School.Services;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

import com.example.School.Repository.AcademicSyllabusRepository;
import com.example.School.entity.Syllabus;

@Service
public class AcademicSyllabusService {

    @Autowired
    private AcademicSyllabusRepository academicSyllabusRepository;

    public List<Syllabus> getAllSyllabus() {
        return academicSyllabusRepository.findAll();
    }

    public void saveSyllabus(Syllabus syllabus) {
        academicSyllabusRepository.save(syllabus);
    }

    public Syllabus getSyllabusById(Long id) {
        return academicSyllabusRepository.findById(id).orElse(null);
    }

    public void deleteSyllabus(Long id) {
        academicSyllabusRepository.deleteById(id);
    }
}

