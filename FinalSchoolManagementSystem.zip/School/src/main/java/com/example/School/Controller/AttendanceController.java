package com.example.School.Controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.School.Services.AttendanceService;
import com.example.School.entity.Attendance;
import com.example.School.entity.Result;
import com.example.School.entity.Status;

@Controller
public class AttendanceController {

    @Autowired
    private AttendanceService attendanceService;

    @GetMapping("/attendance")
    public String showAttendanceForm(Model model) {
        model.addAttribute("students", attendanceService.getAllStudents());
        return "attendance";
    }

    @PostMapping("/markAttendance")
    public String markAttendance(@RequestParam Long studentId, @RequestParam Status status) {
        attendanceService.markAttendance(studentId, status);
        return "redirect:/attendanceList";
    }

    @GetMapping("/attendanceList")
    public String getAttendanceList(Model model) {
        model.addAttribute("attendanceList", attendanceService.getAllAttendanceRecords());
        return "attendanceList";
    }

    @GetMapping("/updateAttendance/{id}")
    public String showUpdateAttendanceForm(@PathVariable Long id, Model model) {
        Attendance attendance = attendanceService.getAttendanceById(id);
        model.addAttribute("attendance", attendance);
        model.addAttribute("students", attendanceService.getAllStudents());
        return "updateAttendance";
    }

    @PostMapping("/updateAttendance")
    public String updateAttendance(@RequestParam Long id, @RequestParam Status status) {
        attendanceService.updateAttendance(id, status);
        return "redirect:/attendanceList";
    }

    @GetMapping("/deleteAttendance/{id}")
    public String deleteAttendance(@PathVariable Long id) {
        attendanceService.deleteAttendance(id);
        return "redirect:/attendanceList";
    }
    
    @GetMapping("/viewAttendence")
    public String viewResult(Model model) {
        List<Attendance> attendenceList = attendanceService.getAllAttendanceRecords();
        model.addAttribute("attendenceList", attendenceList);
        return "viewAttendence";  
    }
}
