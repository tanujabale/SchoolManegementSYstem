package com.example.School.Services;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.School.Repository.ResultRepository;
import com.example.School.entity.Result;

import java.util.List;
import java.util.Optional;

@Service
public class ResultService {

    @Autowired
    private ResultRepository resultRepository;

    // Fetch all results
    public List<Result> getAllResults() {
        return resultRepository.findAll();
    }

    // Fetch a specific result by ID
    public Optional<Result> getResultById(Long id) {
        return resultRepository.findById(id);
    }
    

    // Add a new result
    public Result addResult(Result result) {
        return resultRepository.save(result);
    }

    // Update an existing result
    public Result updateResult(Long id, Result updatedResult) {
        return resultRepository.findById(id)
                .map(result -> {
                    result.setName(updatedResult.getName());
                    result.setMarathi(updatedResult.getMarathi());
                    result.setEnglish(updatedResult.getEnglish());
                    result.setHindi(updatedResult.getHindi());
                    result.setMathematics(updatedResult.getMathematics());
                    result.setHistory(updatedResult.getHistory());
                    result.setGeography(updatedResult.getGeography());
                    result.setScience(updatedResult.getScience());
//                    result.setTotalMarks(updatedResult.getTotalMarks());
//                    result.setPercentage(updatedResult.getPercentage());

                    return resultRepository.save(result);
                })
                .orElseThrow(() -> new IllegalArgumentException("Invalid result ID: " + id));
    }

    // Delete a result by ID
    public void deleteResult(Long id) {
        resultRepository.deleteById(id);
    }

    // Save a result (could be for creating or updating)
    public Result saveResult(Result result) {
        return resultRepository.save(result);
    }

    // Get a list of all results
    public List<Result> resultList() {
        return resultRepository.findAll();
    }
     
  
}

