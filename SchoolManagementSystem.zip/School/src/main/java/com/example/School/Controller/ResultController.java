package com.example.School.Controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.example.School.Services.ResultService;
import com.example.School.Services.StudentService;
import com.example.School.entity.Result;
import com.example.School.entity.Student;
import com.example.School.entity.Subject;

import java.util.List;
import java.util.Optional;

@Controller
public class ResultController {

    @Autowired
    private ResultService resultService;

    @GetMapping("/enter")
    public String showResultForm(Model model) {
        model.addAttribute("result", new Result());
        return "enterMarks";  // Thymeleaf template for entering marks
    }

    // 2. Handle form submission and display the list of results
    @PostMapping("/submit")
    public String submitResult(@ModelAttribute("result") Result result, Model model) {
        resultService.saveResult(result);
        return "redirect:/list";  // Redirect to list of results
    }

    // 3. Display the list of submitted results
    @GetMapping("/list")
    public String showResultList(Model model) {
        List<Result> resultList = resultService.getAllResults();
        model.addAttribute("results", resultList);
        return "resultList";  // Thymeleaf template for displaying list of results
    }

    // 4. Handle the update of a result
    @GetMapping("/edit/{id}")
    public String editResultForm(@PathVariable("id") Long id, Model model) {
        Optional<Result> result = resultService.getResultById(id);
        model.addAttribute("result", result);
        return "editResult";  // Thymeleaf template for editing result
    }

    @PostMapping("/update/{id}")
    public String updateResult(@PathVariable("id") Long id, @ModelAttribute("result") Result updatedResult) {
        resultService.updateResult(id, updatedResult);
        return "redirect:/list";  // Redirect to the list of results after updating
    }

    @GetMapping("/delete/{id}")
    public String deleteResult(@PathVariable("id") Long id) {
        resultService.deleteResult(id);
        return "redirect:/list";  // Redirect to the list of results after deletion
    }
    
//    @GetMapping("/Displayresult")
//    public String viewSubjetList(Model model) {
//        List<Result> resultList = resultService.getAllResults();
//        model.addAttribute("resultList", resultList);
//        return "viewResult";  
//    }
    
   

    @GetMapping("/viewresult")
    public String viewResult(Model model) {
        List<Result> resultList = resultService.getAllResults();
        model.addAttribute("resultList", resultList);
        return "viewResult";  
    }
} 
