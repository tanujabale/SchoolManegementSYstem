package com.example.School.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.School.Services.FacultyService;
import com.example.School.entity.FacultyHome;


@Controller
public class FacultyLoginController {
	@Autowired
		private FacultyService facultyservice;

	@GetMapping("/facultylogin")
		public String getfacultyLogin(Model model) {
			
			model.addAttribute("facultyHome", new FacultyHome());
			
			return "facultylogin";
			
	  }
	@PostMapping("/facultyloginstatus")
	public String getfacultylogStatus(@Validated @ModelAttribute("facultyHome") FacultyHome facultyHome, BindingResult bindResult, Model model) {
	    if (bindResult.hasErrors()) {
	        return "facultylogin";
	    }

	    List<com.example.School.entity.Faculty> dbfacultyList = facultyservice.FacultyList();
	    boolean found = false;

	    for (com.example.School.entity.Faculty dba : dbfacultyList) {
	        // Check for null values before using equals
	        if (dba.getUsername() != null && dba.getPassword() != null &&
	            dba.getUsername().equals(facultyHome.getUsername()) && 
	            dba.getPassword().equals(facultyHome.getPassword())) {
	            
	            found = true;
	            break;
	        }
	    }

	    if (found) {
	        return "facultydashboard";
	    } else {
	        model.addAttribute("error", "Incorrect username or password");
	        return "facultylogin";
	    }
	}


		
	}
//	@GetMapping("/logout")
//	public String logout(HttpSession session) {
//	    session.invalidate();  // Invalidate the current session
//	    return "redirect:/";  // Redirect to index1 page
//	}
	






