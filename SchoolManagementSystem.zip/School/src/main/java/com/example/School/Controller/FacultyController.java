package com.example.School.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.School.Repository.FacultyRepository;
import com.example.School.Services.FacultyService;
import com.example.School.entity.Faculty;

@Controller
public class FacultyController {

    @Autowired
    private FacultyRepository facultyRepository;

    @GetMapping("/addFaculty")
    public String showAddFacultyForm(Model model) {
        model.addAttribute("faculty", new Faculty());
        return "add-faculty";
    }

    @PostMapping("/saveFaculty")
    public String saveFaculty(@ModelAttribute("faculty") Faculty faculty) {
        facultyRepository.save(faculty);
        return "redirect:/listFaculty";
    }

    @GetMapping("/listFaculty")
    public String listFaculty(Model model) {
        model.addAttribute("faculties", facultyRepository.findAll());
        return "list-faculty";
    }

    @GetMapping("/editFaculty/{id}")
    public String showUpdateForm(@PathVariable("id") Long id, Model model) {
        Faculty faculty = facultyRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid faculty Id:" + id));
        model.addAttribute("faculty", faculty);
        return "update-faculty";
    }

    
    public String updateFaculty(@PathVariable("id") Long id, @ModelAttribute("faculty") Faculty faculty) {
        faculty.setId(id);
        facultyRepository.save(faculty);
        return "redirect:/listFaculty";
    }

    @GetMapping("/deleteFaculty/{id}")
    public String deleteFaculty(@PathVariable("id") Long id) {
        facultyRepository.deleteById(id);
        return "redirect:/listFaculty";
    }
    

    @Autowired
    private FacultyService facultyService;

    @GetMapping("/viewFaculty")
    public String viewFacultyList(Model model) {
        List<Faculty> facultyList = facultyService.getAllFaculty();
        model.addAttribute("facultyList", facultyList);
        return "viewFacultyy";  
    }
    
    
    

    
    }



