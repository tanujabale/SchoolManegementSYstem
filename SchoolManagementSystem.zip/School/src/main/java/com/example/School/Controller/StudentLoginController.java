package com.example.School.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.School.Services.StudentService;
import com.example.School.entity.FacultyHome;
import com.example.School.entity.StudentHome;
@Controller
public class StudentLoginController {

	
	
	@Autowired
		private StudentService studentservice;

	@GetMapping("/studentlogin")
		public String getstudentLogin(Model model) {
			
			model.addAttribute("studentHome", new StudentHome());
			
			return "studentlogin"; 
			
	  }
	@PostMapping("/studentloginstatus")
	public String getstudentlogStatus(@Validated @ModelAttribute("studentHome") StudentHome studentHome, BindingResult bindResult, Model model) {
	    if (bindResult.hasErrors()) {
	        return "studentlogin";
	    }

	    List<com.example.School.entity.Student> dbstudentList = studentservice.StudentList();
	    boolean found = false;

	    for (com.example.School.entity.Student dba : dbstudentList) {
	        // Check for null values before using equals
	        if (dba.getUsername() != null && dba.getPassword() != null &&
	            dba.getUsername().equals(studentHome.getUsername()) && 
	            dba.getPassword().equals(studentHome.getPassword())) {
	            
	            found = true;
	            break;
	        }
	    }

	    if (found) {
	        return "studentdashboard";
	    } else {
	        model.addAttribute("error", "Incorrect username or password");
	        return "studentlogin";
	    }
	}
}